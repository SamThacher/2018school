/*
 * OptionHandler.java
* Copyright (c) 2018 Georgetown University.  All Rights Reserved.
*/

public interface OptionHandler
{

	public void setOptions( java.lang.String[] options ) throws java.lang.Exception;

}
