/*
* TrainTestSets.java
* Copyright (c) 2018 Georgetown University.All Rights Reserved.
*/

public class TrainTestSets implements OptionHandler
{

	protected DataSet train;
	protected DataSet test;

	public TrainTestSets()
	{
		train = new DataSet();
		test = new DataSet();
	}
	public TrainTestSets( java.lang.String [] options ) throws Exception
	{
		this.setOptions(options);

	}
	public TrainTestSets( DataSet train, DataSet test )
	{
		this.train = train;
		this.test = test;
	}
	public DataSet getTrainingSet()
	{
		return train;
	}
	public DataSet getTestingSet()
	{
		return test;
	}
	public void setTrainingSet( DataSet train )
	{
		this.train = train;
	}
	public void setTestingSet( DataSet test )
	{
		this.test = test;
	}
	public void setOptions( java.lang.String[] options ) throws Exception
	{
		if(options[0].contains("-t") )
		{
			try
			{
				java.lang.String fil = options[1];
				train.load(fil);

			}
			catch(java.lang.ArrayIndexOutOfBoundsException e) {
				System.out.println("Training file is required");
			}
			catch(java.lang.Exception e) 
			{
				e.printStackTrace();
			}
		}
		try
		{
			if(options[2].contains("-T"))
			{
					java.lang.String fil = options[3];
					test.load(fil);
			}
		}
		catch(java.lang.ArrayIndexOutOfBoundsException e) {
				// System.out.println("No test file");
			}
			catch(java.lang.Exception e) 
			{
				e.printStackTrace();
			}

	}
	public java.lang.String toString()
	{
		return train.toString() + "\n\n" + test.toString();
	}
}