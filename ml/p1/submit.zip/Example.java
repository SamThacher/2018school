
public class Example extends java.util.ArrayList<java.lang.Double>
{
	
	// Constructor
	public Example()
	{
		super();
	}
	public Example(int n)
	{
		super(n);
	}
	
}